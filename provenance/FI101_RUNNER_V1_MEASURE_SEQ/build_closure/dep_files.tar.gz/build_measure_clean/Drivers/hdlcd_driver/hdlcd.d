build_measure_clean/Drivers/hdlcd_driver/hdlcd.o: \
 Drivers/hdlcd_driver/hdlcd.c Drivers/hdlcd_driver/hdlcd.h Sleep/Sleep.h \
 Serial/serial.h Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h
Drivers/hdlcd_driver/hdlcd.h:
Sleep/Sleep.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
