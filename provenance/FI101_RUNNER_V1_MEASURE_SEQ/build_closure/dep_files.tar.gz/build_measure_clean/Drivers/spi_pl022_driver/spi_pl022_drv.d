build_measure_clean/Drivers/spi_pl022_driver/spi_pl022_drv.o: \
 Drivers/spi_pl022_driver/spi_pl022_drv.c \
 Drivers/spi_pl022_driver/../spi_pl022_driver/spi_pl022_drv.h
Drivers/spi_pl022_driver/../spi_pl022_driver/spi_pl022_drv.h:
