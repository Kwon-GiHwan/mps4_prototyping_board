build_measure_clean/Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.o: \
 Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.c \
 Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.h \
 Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_reg_map.h
Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.h:
Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_reg_map.h:
