build_measure_clean/Drivers/i2c_sbcon_driver/i2c_sbcon_drv.o: \
 Drivers/i2c_sbcon_driver/i2c_sbcon_drv.c \
 Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h \
 Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h
Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h:
Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h:
