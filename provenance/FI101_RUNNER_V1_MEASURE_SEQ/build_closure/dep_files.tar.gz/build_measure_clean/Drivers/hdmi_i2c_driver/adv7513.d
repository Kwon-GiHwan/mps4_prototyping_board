build_measure_clean/Drivers/hdmi_i2c_driver/adv7513.o: \
 Drivers/hdmi_i2c_driver/adv7513.c Drivers/hdmi_i2c_driver/adv7513.h \
 Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h Device_SSE-320/Driver_Common.h \
 Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h \
 Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h Sleep/Sleep.h
Drivers/hdmi_i2c_driver/adv7513.h:
Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h:
Device_SSE-320/Driver_Common.h:
Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h:
Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h:
Sleep/Sleep.h:
