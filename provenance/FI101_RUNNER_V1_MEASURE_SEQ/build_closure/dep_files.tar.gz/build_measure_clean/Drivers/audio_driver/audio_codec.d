build_measure_clean/Drivers/audio_driver/audio_codec.o: \
 Drivers/audio_driver/audio_codec.c Drivers/audio_driver/audio_codec.h \
 Drivers/i2c_sbcon_driver/Driver_I2C.h Device_SSE-320/Driver_Common.h
Drivers/audio_driver/audio_codec.h:
Drivers/i2c_sbcon_driver/Driver_I2C.h:
Device_SSE-320/Driver_Common.h:
