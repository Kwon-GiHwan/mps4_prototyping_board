build_measure_clean/Drivers/cmsdk_apb_uart_driver/Driver_USART.o: \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.c \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h Device_SSE-320/cmsis_driver_config.h \
 Device_SSE-320/system_core_init.h \
 Device_SSE-320/Selftest_config/device_cfg.h \
 Device_SSE-320/device_definition.h \
 Drivers/cmsdk_apb_uart_driver/cmsdk_apb_uart.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/../Drivers/spi_pl022_driver/spi_pl022_drv.h \
 Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h \
 Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h \
 Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.h \
 Drivers/syscounter_armv8_driver/syscounter_armv8-m_read_drv.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h \
 Drivers/qspi_flash_micron_driver/qspi_flash.h \
 Drivers/qspi_flash_micron_driver/qspi_flash_micron.h \
 Drivers/qspi_flash_micron_driver/qspi_flash.h \
 Drivers/hdmi_i2c_driver/adv7513.h Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h \
 Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h \
 Device_SSE-320/platform_base_address.h Device_SSE-320/ARMCM85.h \
 Device_SSE-320/core_cm85.h Device_SSE-320/cmsis_version.h \
 Device_SSE-320/cmsis_compiler.h \
 /opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h \
 Device_SSE-320/mpu_armv8.h Device_SSE-320/pmu_armv8.h \
 Device_SSE-320/cachel1_armv7.h Device_SSE-320/pac_armv81.h \
 Device_SSE-320/cm85_system.h
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
Device_SSE-320/cmsis_driver_config.h:
Device_SSE-320/system_core_init.h:
Device_SSE-320/Selftest_config/device_cfg.h:
Device_SSE-320/device_definition.h:
Drivers/cmsdk_apb_uart_driver/cmsdk_apb_uart.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/../Drivers/spi_pl022_driver/spi_pl022_drv.h:
Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h:
Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h:
Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.h:
Drivers/syscounter_armv8_driver/syscounter_armv8-m_read_drv.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h:
Drivers/qspi_flash_micron_driver/qspi_flash.h:
Drivers/qspi_flash_micron_driver/qspi_flash_micron.h:
Drivers/qspi_flash_micron_driver/qspi_flash.h:
Drivers/hdmi_i2c_driver/adv7513.h:
Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h:
Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h:
Device_SSE-320/platform_base_address.h:
Device_SSE-320/ARMCM85.h:
Device_SSE-320/core_cm85.h:
Device_SSE-320/cmsis_version.h:
Device_SSE-320/cmsis_compiler.h:
/opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h:
Device_SSE-320/mpu_armv8.h:
Device_SSE-320/pmu_armv8.h:
Device_SSE-320/cachel1_armv7.h:
Device_SSE-320/pac_armv81.h:
Device_SSE-320/cm85_system.h:
