build_measure_clean/Drivers/cmsdk_apb_uart_driver/cmsdk_apb_uart.o: \
 Drivers/cmsdk_apb_uart_driver/cmsdk_apb_uart.c \
 Drivers/cmsdk_apb_uart_driver/cmsdk_apb_uart.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h
Drivers/cmsdk_apb_uart_driver/cmsdk_apb_uart.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
