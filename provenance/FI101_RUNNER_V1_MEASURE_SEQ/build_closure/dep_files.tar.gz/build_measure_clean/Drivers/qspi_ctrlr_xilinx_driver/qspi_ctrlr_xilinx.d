build_measure_clean/Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.o: \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.c \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h:
