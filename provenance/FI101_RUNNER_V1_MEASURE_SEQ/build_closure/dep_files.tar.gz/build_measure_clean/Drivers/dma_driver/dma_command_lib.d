build_measure_clean/Drivers/dma_driver/dma_command_lib.o: \
 Drivers/dma_driver/dma_command_lib.c \
 Drivers/dma_driver/dma_command_lib.h Drivers/dma_driver/dma_regdef.h \
 Drivers/dma_driver/dma_reg_typedef.h
Drivers/dma_driver/dma_command_lib.h:
Drivers/dma_driver/dma_regdef.h:
Drivers/dma_driver/dma_reg_typedef.h:
