build_measure_clean/Drivers/Common/logging/logging.o: \
 Drivers/Common/logging/logging.c Drivers/Common/logging/logging.h
Drivers/Common/logging/logging.h:
