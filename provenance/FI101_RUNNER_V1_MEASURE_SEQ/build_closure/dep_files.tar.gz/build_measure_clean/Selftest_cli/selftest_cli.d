build_measure_clean/Selftest_cli/selftest_cli.o: \
 Selftest_cli/selftest_cli.c Selftest_cli/selftest_cli.h Sleep/Sleep.h \
 Device_SSE-320/project_defines.h Serial/serial.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h
Selftest_cli/selftest_cli.h:
Sleep/Sleep.h:
Device_SSE-320/project_defines.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
