build_measure_clean/Tests/csi_ddr_hdmi_test/imx415.o: \
 Tests/csi_ddr_hdmi_test/imx415.c \
 Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h \
 Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h \
 Tests/csi_ddr_hdmi_test/imx415.h
Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h:
Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h:
Tests/csi_ddr_hdmi_test/imx415.h:
