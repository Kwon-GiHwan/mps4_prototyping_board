build_measure_clean/Tests/u85_test/u85_Convolution.o: \
 Tests/u85_test/u85_Convolution.c \
 Device_SSE-320/Selftest_config/device_cfg.h \
 Drivers/u85_driver/interface.h Drivers/Common/logging/logging.h \
 Serial/serial.h Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h Device_SSE-320/ARMCM85.h \
 Device_SSE-320/core_cm85.h Device_SSE-320/cmsis_version.h \
 Device_SSE-320/cmsis_compiler.h \
 /opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h \
 Device_SSE-320/mpu_armv8.h Device_SSE-320/pmu_armv8.h \
 Device_SSE-320/cachel1_armv7.h Device_SSE-320/pac_armv81.h \
 Device_SSE-320/cm85_system.h Drivers/u85_driver/u85.h \
 Tests/u85_test/./test3/test3_include.h \
 Tests/u85_test/./test3/test3_cmd_stream.h \
 Tests/u85_test/./test3/test3_cmd_stream_1024.h \
 Tests/u85_test/./test3/test3_weight_stream.h \
 Tests/u85_test/./test3/test3_weight_stream_1024.h
Device_SSE-320/Selftest_config/device_cfg.h:
Drivers/u85_driver/interface.h:
Drivers/Common/logging/logging.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
Device_SSE-320/ARMCM85.h:
Device_SSE-320/core_cm85.h:
Device_SSE-320/cmsis_version.h:
Device_SSE-320/cmsis_compiler.h:
/opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h:
Device_SSE-320/mpu_armv8.h:
Device_SSE-320/pmu_armv8.h:
Device_SSE-320/cachel1_armv7.h:
Device_SSE-320/pac_armv81.h:
Device_SSE-320/cm85_system.h:
Drivers/u85_driver/u85.h:
Tests/u85_test/./test3/test3_include.h:
Tests/u85_test/./test3/test3_cmd_stream.h:
Tests/u85_test/./test3/test3_cmd_stream_1024.h:
Tests/u85_test/./test3/test3_weight_stream.h:
Tests/u85_test/./test3/test3_weight_stream_1024.h:
