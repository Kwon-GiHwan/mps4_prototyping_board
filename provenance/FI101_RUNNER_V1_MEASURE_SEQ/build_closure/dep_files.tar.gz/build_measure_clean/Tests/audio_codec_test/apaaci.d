build_measure_clean/Tests/audio_codec_test/apaaci.o: \
 Tests/audio_codec_test/apaaci.c Drivers/audio_driver/audio_codec.h \
 Drivers/i2c_sbcon_driver/Driver_I2C.h Device_SSE-320/Driver_Common.h \
 Drivers/audio_driver/audio_transmitter.h Device_SSE-320/ARMCM85.h \
 Device_SSE-320/core_cm85.h Device_SSE-320/cmsis_version.h \
 Device_SSE-320/cmsis_compiler.h \
 /opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h \
 Device_SSE-320/mpu_armv8.h Device_SSE-320/pmu_armv8.h \
 Device_SSE-320/cachel1_armv7.h Device_SSE-320/pac_armv81.h \
 Device_SSE-320/cm85_system.h Sleep/Sleep.h \
 Tests/audio_codec_test/apaaci.h Drivers/audio_driver/aud_formatter.h \
 Drivers/Common/logging/logging.h Serial/serial.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/cachel1_armv7.h
Drivers/audio_driver/audio_codec.h:
Drivers/i2c_sbcon_driver/Driver_I2C.h:
Device_SSE-320/Driver_Common.h:
Drivers/audio_driver/audio_transmitter.h:
Device_SSE-320/ARMCM85.h:
Device_SSE-320/core_cm85.h:
Device_SSE-320/cmsis_version.h:
Device_SSE-320/cmsis_compiler.h:
/opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h:
Device_SSE-320/mpu_armv8.h:
Device_SSE-320/pmu_armv8.h:
Device_SSE-320/cachel1_armv7.h:
Device_SSE-320/pac_armv81.h:
Device_SSE-320/cm85_system.h:
Sleep/Sleep.h:
Tests/audio_codec_test/apaaci.h:
Drivers/audio_driver/aud_formatter.h:
Drivers/Common/logging/logging.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/cachel1_armv7.h:
