build_measure_clean/Tests/dma350xfers_test/dma_xfers.o: \
 Tests/dma350xfers_test/dma_xfers.c \
 Device_SSE-320/platform_base_address.h Sleep/Sleep.h \
 Device_SSE-320/cmsis_compiler.h \
 /opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h \
 Drivers/interrupt_ctrlr_interface/interrupt_drv.h \
 Device_SSE-320/ARMCM85.h Device_SSE-320/core_cm85.h \
 Device_SSE-320/cmsis_version.h Device_SSE-320/cmsis_compiler.h \
 Device_SSE-320/mpu_armv8.h Device_SSE-320/pmu_armv8.h \
 Device_SSE-320/cachel1_armv7.h Device_SSE-320/pac_armv81.h \
 Device_SSE-320/cm85_system.h Device_SSE-320/Selftest_config/device_cfg.h \
 Device_SSE-320/sse320_irq.h Drivers/dma_driver/dma_interrupt.h \
 Drivers/dma_driver/dma_config_parameters.h \
 Tests/dma350xfers_test/dma_xfers.h Drivers/dma_driver/dma_regdef.h \
 Drivers/dma_driver/dma_command_lib.h Drivers/dma_driver/dma_regdef.h \
 Drivers/dma_driver/dma_reg_typedef.h
Device_SSE-320/platform_base_address.h:
Sleep/Sleep.h:
Device_SSE-320/cmsis_compiler.h:
/opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h:
Drivers/interrupt_ctrlr_interface/interrupt_drv.h:
Device_SSE-320/ARMCM85.h:
Device_SSE-320/core_cm85.h:
Device_SSE-320/cmsis_version.h:
Device_SSE-320/cmsis_compiler.h:
Device_SSE-320/mpu_armv8.h:
Device_SSE-320/pmu_armv8.h:
Device_SSE-320/cachel1_armv7.h:
Device_SSE-320/pac_armv81.h:
Device_SSE-320/cm85_system.h:
Device_SSE-320/Selftest_config/device_cfg.h:
Device_SSE-320/sse320_irq.h:
Drivers/dma_driver/dma_interrupt.h:
Drivers/dma_driver/dma_config_parameters.h:
Tests/dma350xfers_test/dma_xfers.h:
Drivers/dma_driver/dma_regdef.h:
Drivers/dma_driver/dma_command_lib.h:
Drivers/dma_driver/dma_regdef.h:
Drivers/dma_driver/dma_reg_typedef.h:
