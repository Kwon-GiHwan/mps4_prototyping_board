build_measure_clean/Tests/lcm_test/lcm.o: Tests/lcm_test/lcm.c \
 Drivers/Common/logging/logging.h Serial/serial.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h Sleep/Sleep.h Tests/lcm_test/lcm.h \
 Drivers/lcm_driver/lcm_drv.h Drivers/lcm_driver/lcm_otp_layout.h
Drivers/Common/logging/logging.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
Sleep/Sleep.h:
Tests/lcm_test/lcm.h:
Drivers/lcm_driver/lcm_drv.h:
Drivers/lcm_driver/lcm_otp_layout.h:
