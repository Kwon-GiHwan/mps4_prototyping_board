build_measure_clean/Tests/dma350registers_test/dma_regtest.o: \
 Tests/dma350registers_test/dma_regtest.c \
 Device_SSE-320/Selftest_config/device_cfg.h \
 Device_SSE-320/platform_base_address.h Sleep/Sleep.h \
 Device_SSE-320/cmsis_compiler.h \
 /opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h \
 Tests/dma350registers_test/dma_regtest.h Drivers/dma_driver/dma_regdef.h \
 Drivers/dma_driver/dma_config_parameters.h
Device_SSE-320/Selftest_config/device_cfg.h:
Device_SSE-320/platform_base_address.h:
Sleep/Sleep.h:
Device_SSE-320/cmsis_compiler.h:
/opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h:
Tests/dma350registers_test/dma_regtest.h:
Drivers/dma_driver/dma_regdef.h:
Drivers/dma_driver/dma_config_parameters.h:
