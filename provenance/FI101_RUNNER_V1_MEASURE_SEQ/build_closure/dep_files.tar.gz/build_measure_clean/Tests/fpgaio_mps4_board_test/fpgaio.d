build_measure_clean/Tests/fpgaio_mps4_board_test/fpgaio.o: \
 Tests/fpgaio_mps4_board_test/fpgaio.c \
 Tests/fpgaio_mps4_board_test/fpgaio.h Serial/serial.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h
Tests/fpgaio_mps4_board_test/fpgaio.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
