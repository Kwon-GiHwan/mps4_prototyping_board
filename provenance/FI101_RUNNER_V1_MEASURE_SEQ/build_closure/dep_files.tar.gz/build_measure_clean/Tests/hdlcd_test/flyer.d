build_measure_clean/Tests/hdlcd_test/flyer.o: Tests/hdlcd_test/flyer.c
