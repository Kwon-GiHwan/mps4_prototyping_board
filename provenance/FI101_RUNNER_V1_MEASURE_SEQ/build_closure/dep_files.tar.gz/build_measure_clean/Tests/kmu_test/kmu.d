build_measure_clean/Tests/kmu_test/kmu.o: Tests/kmu_test/kmu.c \
 Drivers/Common/logging/logging.h Serial/serial.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h Drivers/kmu_driver/kmu_drv.h \
 Tests/kmu_test/kmu.h
Drivers/Common/logging/logging.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
Drivers/kmu_driver/kmu_drv.h:
Tests/kmu_test/kmu.h:
