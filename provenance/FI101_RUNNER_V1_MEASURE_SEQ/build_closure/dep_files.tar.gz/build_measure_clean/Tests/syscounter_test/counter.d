build_measure_clean/Tests/syscounter_test/counter.o: \
 Tests/syscounter_test/counter.c Tests/syscounter_test/counter.h \
 Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.h
Tests/syscounter_test/counter.h:
Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.h:
