build_measure_clean/Tests/otp_test/apotp.o: Tests/otp_test/apotp.c \
 Tests/otp_test/apotp.h Device_SSE-320/platform_base_address.h \
 Sleep/Sleep.h Device_SSE-320/cmsis_compiler.h \
 /opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h \
 Drivers/Common/logging/logging.h Serial/serial.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h
Tests/otp_test/apotp.h:
Device_SSE-320/platform_base_address.h:
Sleep/Sleep.h:
Device_SSE-320/cmsis_compiler.h:
/opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h:
Drivers/Common/logging/logging.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
