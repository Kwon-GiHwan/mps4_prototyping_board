build_measure_clean/Tests/sam_test/sam.o: Tests/sam_test/sam.c \
 Drivers/Common/logging/logging.h Serial/serial.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h Tests/sam_test/sam.h
Drivers/Common/logging/logging.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
Tests/sam_test/sam.h:
