build_measure_clean/Tests/memory_test/apmem.o: Tests/memory_test/apmem.c \
 Tests/memory_test/apmem.h Drivers/Common/logging/logging.h \
 Serial/serial.h Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h
Tests/memory_test/apmem.h:
Drivers/Common/logging/logging.h:
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
