build_measure_clean/Tests/uart_mps4_test/uart.o: \
 Tests/uart_mps4_test/uart.c Tests/uart_mps4_test/uart.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h Sleep/Sleep.h \
 Device_SSE-320/device_definition.h \
 Device_SSE-320/Selftest_config/device_cfg.h \
 Drivers/cmsdk_apb_uart_driver/cmsdk_apb_uart.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/../Drivers/spi_pl022_driver/spi_pl022_drv.h \
 Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h \
 Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h \
 Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.h \
 Drivers/syscounter_armv8_driver/syscounter_armv8-m_read_drv.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h \
 Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h \
 Drivers/qspi_flash_micron_driver/qspi_flash.h \
 Drivers/qspi_flash_micron_driver/qspi_flash_micron.h \
 Drivers/qspi_flash_micron_driver/qspi_flash.h \
 Drivers/hdmi_i2c_driver/adv7513.h Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h \
 Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h Serial/serial.h
Tests/uart_mps4_test/uart.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
Sleep/Sleep.h:
Device_SSE-320/device_definition.h:
Device_SSE-320/Selftest_config/device_cfg.h:
Drivers/cmsdk_apb_uart_driver/cmsdk_apb_uart.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/../Drivers/spi_pl022_driver/spi_pl022_drv.h:
Drivers/i2c_sbcon_driver/i2c_sbcon_drv.h:
Drivers/cmsdk_apb_gpio_driver/Driver_GPIO.h:
Drivers/syscounter_armv8_driver/syscounter_armv8-m_cntrl_drv.h:
Drivers/syscounter_armv8_driver/syscounter_armv8-m_read_drv.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr.h:
Drivers/qspi_ctrlr_xilinx_driver/qspi_ctrlr_xilinx.h:
Drivers/qspi_flash_micron_driver/qspi_flash.h:
Drivers/qspi_flash_micron_driver/qspi_flash_micron.h:
Drivers/qspi_flash_micron_driver/qspi_flash.h:
Drivers/hdmi_i2c_driver/adv7513.h:
Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h:
Drivers/hdmi_i2c_driver/hdmi_i2c_drv.h:
Serial/serial.h:
