build_measure_clean/Tests/timer_test/timer.o: Tests/timer_test/timer.c \
 Tests/timer_test/timer.h Device_SSE-320/ARMCM85.h \
 Device_SSE-320/core_cm85.h Device_SSE-320/cmsis_version.h \
 Device_SSE-320/cmsis_compiler.h \
 /opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h \
 Device_SSE-320/mpu_armv8.h Device_SSE-320/pmu_armv8.h \
 Device_SSE-320/cachel1_armv7.h Device_SSE-320/pac_armv81.h \
 Device_SSE-320/cm85_system.h Device_SSE-320/cachel1_armv7.h \
 Sleep/Sleep.h
Tests/timer_test/timer.h:
Device_SSE-320/ARMCM85.h:
Device_SSE-320/core_cm85.h:
Device_SSE-320/cmsis_version.h:
Device_SSE-320/cmsis_compiler.h:
/opt/arm/ml-embedded-evaluation-kit/dependencies/cmsis-6/CMSIS/Core/Include/cmsis_gcc.h:
Device_SSE-320/mpu_armv8.h:
Device_SSE-320/pmu_armv8.h:
Device_SSE-320/cachel1_armv7.h:
Device_SSE-320/pac_armv81.h:
Device_SSE-320/cm85_system.h:
Device_SSE-320/cachel1_armv7.h:
Sleep/Sleep.h:
