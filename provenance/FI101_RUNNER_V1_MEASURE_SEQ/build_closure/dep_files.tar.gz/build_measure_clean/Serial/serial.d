build_measure_clean/Serial/serial.o: Serial/serial.c Serial/serial.h \
 Drivers/cmsdk_apb_uart_driver/Driver_USART.h \
 Device_SSE-320/Driver_Common.h \
 Device_SSE-320/Selftest_config/device_cfg.h
Serial/serial.h:
Drivers/cmsdk_apb_uart_driver/Driver_USART.h:
Device_SSE-320/Driver_Common.h:
Device_SSE-320/Selftest_config/device_cfg.h:
